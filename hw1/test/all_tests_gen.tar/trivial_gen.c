#include <stdio.h>
#define read(x) scanf("%d",&x)
#define write(x) printf("%d\n",x)

void cs512foo( ) {
    int cs512a;
    read(cs512a) ;
    write(cs512a) ;
}

int main( ) {
  cs512foo( ) ;
}
