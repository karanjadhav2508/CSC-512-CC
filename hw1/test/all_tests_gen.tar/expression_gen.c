#include <stdio.h>
#define read(x) scanf("%d",&x)
#define write(x) printf("%d\n",x)

int main() {
    int cs512a, cs512sum;
    read(cs512a);
    cs512sum = (cs512a+1) *cs512a / 2;
    write(cs512sum);
}
